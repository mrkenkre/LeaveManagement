package com.cg.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="employee_details")
public class Employee {
	
		@Id
		@Pattern(regexp="{6}", message="Id should be 6 digit")
		private long empid;
		@Pattern(regexp="[A-Z][a-z]{4,}",
				message="Name should start with Upper case and should contain only alphabets.")
		private String ename;
		@NotNull
		private String address;
		@NotNull
		private int leaves_avail;
		public long getEmpid() {
			return empid;
		}
		public void setEmpid(long empid) {
			this.empid = empid;
		}
		public String getEname() {
			return ename;
		}
		public void setEname(String ename) {
			this.ename = ename;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public int getLeaves_avail() {
			return leaves_avail;
		}
		public void setLeaves_avail(int leaves_avail) {
			this.leaves_avail = leaves_avail;
		}
		@Override
		public String toString() {
			return "Employee [empid=" + empid + ", ename=" + ename + ", address="
					+ address + ", leaves_avail=" + leaves_avail + "]";
		}
		
}
