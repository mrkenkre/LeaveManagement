package com.cg.beans;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="employee_leave_details")
public class Leave {
	@Id
	private int leave_id;
	@NotNull
	private Date start_date;
	@NotNull
	private Date end_date;
	@NotNull
	private String description;
	@NotNull
	private int leaves_applied;
	@NotNull
	@Pattern(regexp="{6}", message="Id should be 6 digit")
	private long empid;
	public int getLeave_id() {
		return leave_id;
	}
	public void setLeave_id(int leave_id) {
		this.leave_id = leave_id;
	}
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public Date getEnd_date() {
		return end_date;
	}
	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getLeaves_applied() {
		return leaves_applied;
	}
	public void setLeaves_applied(int leaves_applied) {
		this.leaves_applied = leaves_applied;
	}
	public long getEmpid() {
		return empid;
	}
	public void setEmpid(long empid) {
		this.empid = empid;
	}
	@Override
	public String toString() {
		return "Leave [leave_id=" + leave_id + ", start_date=" + start_date
				+ ", end_date=" + end_date + ", description=" + description
				+ ", leaves_applied=" + leaves_applied + ", empid=" + empid
				+ "]";
	}
	

}
