package com.cg.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.beans.Employee;


public class HomeController {
	@RequestMapping("getLeaveDetails.obj")
	public String getRegistrationPage(Model model){
		Employee employee= new Employee();
		model.addAttribute("employeeBean", employee);
		return "Home";
	}
	
	@RequestMapping("empSearch")
	public String employeesearch(Model model,@ModelAttribute("employeeBean") Employee employee){
		System.out.println(employee);
		return null;
	}
}
